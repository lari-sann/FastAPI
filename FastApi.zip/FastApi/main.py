from fastapi import FastAPI
from pytz import timezone
from datetime import datetime
import locale

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World"}

#Ex. 1 - Criar um endpoint que identificar se um número é par ou ímpar "PAR" ou "IMPAR"
#http://127.0.0.1:8000/par-ou-impar/9
@app.get("/par-ou-impar/{numero}")
def par_ou_impar(numero: int):
    if numero % 2 == 0:
        return {"resultado": "PAR"}
    else:
        return {"resultado": "IMPAR"}
    
#Ex. 2 - Informar 3 horarios, de acordo com a cidade que usuário especificar na url (brasilia, tokyo, londres)
@app.get("/hora/{cidade}")
#http://127.0.0.1:8000/hora/brasilia

def obter_horario(cidade: str):

    cidades = {
        "brasilia": "America/Sao_Paulo",
        "tokyo": "Asia/Tokyo",
        "londres": "Europe/London",
    }

    if cidade.lower() in cidades:

        agora = datetime.now()
        agora = agora.astimezone(timezone(cidades[cidade.lower()]))
        horario_atual = agora.strftime("%H:%M")
        return {"cidade": cidade, "horario_atual": horario_atual}

    else:
        return {"error": "Cidade não encontrada"}

#Ex. 3 - retorna o nome do dia da semana (seg, terça, ...) de acordo com o dia atual
@app.get("/diasemana")
#http://127.0.0.1:8000/diasemana

def obter_dia_semana():
    agora = datetime.now()
    locale.setlocale(locale.LC_TIME, 'pt_BR.utf8')
    dia_semana_atual = agora.strftime("%A")
    return {"dia_semana": dia_semana_atual}